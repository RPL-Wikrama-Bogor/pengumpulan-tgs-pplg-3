

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('user.update', $user['id'])); ?>" method="post" class="card p-5">
<?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>

<?php if($errors->any()): ?>
<ul class="alert alert-danger p-3">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
    <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">Nama Anda:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user['name']); ?>">
        </div>
    </div>
    
    <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">Email Anda:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="email" name="email" value="<?php echo e($user['email']); ?>">
        </div>
    </div>
    
      <div class="mb-3 row">
        <label for="role" class="col-sm-2 col-form-label">Tipe Anda:</label>
        <div class="col-sm-10">
            <select name="role" id="role" class="form-select">
                <option selected disabled hidden>Pilih</option>
                <option value="admin" <?php echo e($user['role'] == 'admin' ? 'selected' : ''); ?>>admin</option>
                <option value="cashier" <?php echo e($user['role'] == 'cashier' ? 'selected' : ''); ?>>cashier</option>
            </select>
        </div>
    </div>
    
    <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">Ubah Password Anda?:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="password" name="password" >
        </div>
    </div>


<button type="submit" class="btn btn-primary mt-3">Ubah Data</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\applications\coba2-laravel\resources\views/user/edit.blade.php ENDPATH**/ ?>